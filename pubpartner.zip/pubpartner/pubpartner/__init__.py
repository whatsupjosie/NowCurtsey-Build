"""PubPartner — persistent character cartridges for consistent AI personas."""

from .cartridge import Cartridge, CartridgeValidationError, init_cartridge, load_cartridge
from .memory_store import MEMORY_TYPES, Memory, MemoryStore, MemoryStoreError, ScoredMemory
from .prompt_assembler import AssembledPrompt, assemble_prompt
from .schema import Appearance, CharacterDefinition, Identity, VoiceProfile

__version__ = "0.1.0"

__all__ = [
    "Cartridge",
    "CartridgeValidationError",
    "init_cartridge",
    "load_cartridge",
    "MEMORY_TYPES",
    "Memory",
    "MemoryStore",
    "MemoryStoreError",
    "ScoredMemory",
    "AssembledPrompt",
    "assemble_prompt",
    "Appearance",
    "CharacterDefinition",
    "Identity",
    "VoiceProfile",
]
