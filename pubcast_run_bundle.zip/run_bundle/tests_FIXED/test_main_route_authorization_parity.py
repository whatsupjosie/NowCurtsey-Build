from __future__ import annotations
from starlette.testclient import TestClient
import main
from modules import auth as auth_module


def _token(user_id: str, role: str) -> str:
    return auth_module.create_access_token({"sub": user_id, "role": role})


class HubStub:
    def __init__(self):
        self.production_state = {}
        self.events = []
    def update_production_state(self, payload):
        self.production_state.update(payload)
        return dict(self.production_state)
    async def broadcast_system_event(self, payload):
        self.events.append(payload)
    async def broadcast_presence_update(self, client_id, display_name):
        self.events.append({"client_id": client_id, "display_name": display_name})


class CamerasStub:
    def __init__(self):
        self.program = None
        self.preview = None
    def set_program_source(self, source_id):
        self.program = source_id
        return True
    def set_preview_source(self, source_id):
        self.preview = source_id
        return True
    def get(self, source_id):
        return object()
    def get_program_source(self):
        return type("Cam", (), {"source_id": self.program})() if self.program else None
    def get_preview_source(self):
        return type("Cam", (), {"source_id": self.preview})() if self.preview else None


# NOTE 2026-08-24: These tests previously opened `with TestClient(main.app)` inside
# each function body. That causes a RecursionError under anyio when the session-scoped
# `client` fixture is already holding the lifespan open on the same app instance.
# Fixed by accepting the shared `client` fixture — no new TestClient is created.


def test_main_production_state_requires_mod_when_auth_enforced(client, monkeypatch):
    monkeypatch.setenv("PUBCAST_ENFORCE_AUTH", "1")
    monkeypatch.setattr(main, "hub", HubStub())
    monkeypatch.setattr(main, "_HAS_PUBWORLD_ROUTER", False)
    monkeypatch.setattr(main, "push_production_state_to_pubworld", None)
    assert client.post("/api/state/production", json={"mode": "live"}).status_code == 401
    assert client.post("/api/state/production", json={"mode": "live"},
        headers={"Authorization": f"Bearer {_token('guesty','guest')}"}).status_code == 403
    r = client.post("/api/state/production", json={"mode": "live"},
        headers={"Authorization": f"Bearer {_token('moddy','mod')}"})
    assert r.status_code == 200
    assert r.json()["mode"] == "live"


def test_main_camera_switch_requires_mod_when_auth_enforced(client, monkeypatch):
    monkeypatch.setenv("PUBCAST_ENFORCE_AUTH", "1")
    monkeypatch.setattr(main, "cameras", CamerasStub())
    monkeypatch.setattr(main, "hub", HubStub())
    monkeypatch.setattr(main, "_HAS_PUBWORLD_ROUTER", False)
    monkeypatch.setattr(main, "push_production_state_to_pubworld", None)
    assert client.post("/api/cameras/program/cam-1").status_code == 401
    assert client.post("/api/cameras/program/cam-1",
        headers={"Authorization": f"Bearer {_token('guesty','guest')}"}).status_code == 403
    assert client.post("/api/cameras/program/cam-1",
        headers={"Authorization": f"Bearer {_token('moddy','mod')}"}).status_code == 200


def test_main_session_register_rejects_spoofed_user_when_auth_enforced(client, monkeypatch):
    monkeypatch.setenv("PUBCAST_ENFORCE_AUTH", "1")
    body = {"session_id": "s1", "user_id": "alice", "host_user_id": "alice"}
    assert client.post("/api/session/register", json=body).status_code == 401
    assert client.post("/api/session/register", json=body,
        headers={"Authorization": f"Bearer {_token('bob','guest')}"}).status_code == 403
    assert client.post("/api/session/register", json=body,
        headers={"Authorization": f"Bearer {_token('alice','guest')}"}).status_code == 200


def test_main_avatar_route_rejects_header_token_mismatch_when_auth_enforced(client, monkeypatch):
    monkeypatch.setenv("PUBCAST_ENFORCE_AUTH", "1")
    assert client.post("/api/avatars/me", json={"user_id": "carol"},
        headers={"Authorization": f"Bearer {_token('dave','guest')}"}).status_code == 403
    assert client.post("/api/avatars/me", json={"user_id": "carol"},
        headers={"Authorization": f"Bearer {_token('carol','guest')}",
                 "X-Client-Id": "carol"}).status_code in (200, 404)


def test_main_session_role_requires_mod_when_auth_enforced(client, monkeypatch):
    monkeypatch.setenv("PUBCAST_ENFORCE_AUTH", "1")
    body = {"target_user_id": "alice", "role": "host"}
    assert client.post("/api/session/s1/role", json=body,
        headers={"Authorization": f"Bearer {_token('bob','guest')}"}).status_code == 403
    assert client.post("/api/session/s1/role", json=body,
        headers={"Authorization": f"Bearer {_token('moddy','mod')}"}).status_code in (200, 404)


def test_main_visual_patch_approve_requires_mod_and_persists_when_approved(client, monkeypatch):
    monkeypatch.setenv("PUBCAST_ENFORCE_AUTH", "1")
    body = {"patch_id": "p1", "approved": True}
    assert client.post("/api/visual-patch/approve", json=body,
        headers={"Authorization": f"Bearer {_token('guesty','guest')}"}).status_code == 403
    assert client.post("/api/visual-patch/approve", json=body,
        headers={"Authorization": f"Bearer {_token('moddy','mod')}"}).status_code in (200, 400, 404)
