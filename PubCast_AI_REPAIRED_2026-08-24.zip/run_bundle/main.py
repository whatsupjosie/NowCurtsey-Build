"""PubCast AI canonical entrypoint.

The implementation lives in :mod:`modules.main`.  This thin wrapper keeps the
standard ``python main.py`` / ``uvicorn main:app`` interface while forwarding
live runtime globals (such as ``hub``) instead of copying their initial values.
"""
from modules import main as _impl

app = _impl.app


def __getattr__(name):
    return getattr(_impl, name)


def __dir__():
    return sorted(set(globals()) | set(dir(_impl)))


if __name__ == "__main__":
    import uvicorn
    from modules.appconfig import settings

    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level="debug" if settings.debug else "info",
    )
