#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StudioPhase { Idle, Preview, Program, Recording }
