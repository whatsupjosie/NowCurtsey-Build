#[derive(Debug, Clone)]
pub struct Slate { pub title:String, pub take:u32 }
