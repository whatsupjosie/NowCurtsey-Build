use crate::camera::engine::CameraEngine;
pub fn sync_scene_to_cameras(_engine:&mut CameraEngine, _scene_id:&str) {}
