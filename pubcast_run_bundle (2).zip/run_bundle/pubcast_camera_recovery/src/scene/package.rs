#[derive(Debug, Clone)]
pub struct ScenePackage { pub id:String, pub name:String }
