#[derive(Debug, Clone)]
pub struct CameraAssignment { pub camera_id:String, pub scene_id:String }
