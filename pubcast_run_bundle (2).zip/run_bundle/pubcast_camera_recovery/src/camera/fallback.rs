#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FallbackLevel { None, HoldLastFrame, WideShot }
