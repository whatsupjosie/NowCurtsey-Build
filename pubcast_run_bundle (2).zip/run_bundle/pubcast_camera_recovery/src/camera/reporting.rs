#[derive(Debug, Clone)]
pub struct CameraReport { pub camera_id: String, pub confidence: f32, pub note: String }
