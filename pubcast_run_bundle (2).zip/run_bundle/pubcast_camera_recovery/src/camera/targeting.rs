#[derive(Debug, Clone)]
pub struct CameraTarget { pub id: String, pub position: [f32;3], pub priority: f32 }
