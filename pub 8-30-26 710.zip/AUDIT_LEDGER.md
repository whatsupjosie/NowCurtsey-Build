# PubCast Continuous Audit Ledger

Per PubCast_Continuous_Audit_Prompt.md. Append-only. Never silently overwrite a past entry.

---

### 2026-08-30 — Full pytest baseline, PubCast core
Checked: `cd pubcast && python3 -m pytest tests/ -q --no-header` after real `pip install -r requirements.txt -r requirements-dev.txt` (fastapi 0.141.1, pytest 9.1.1) in a fresh container. `import main` succeeded first, standalone, confirming the app object builds outside pytest.
Verdict: ❓ UNVERIFIED as a stable baseline — see flaws below. Raw numbers are real and reproducible in this environment right now.
Evidence:
```
555 passed, 26 failed, 2 skipped, 10 warnings, 7 errors in 38.58s
```
Full raw output saved at /home/claude/pytest_baseline_full.txt (not committed to repo; local only).
This does NOT match the previously reported "556 passing, 25 failures, 7 errors" from last session's summary — that number was not re-verified before being repeated and should not have been treated as current. Off by one failure. Treating the number above as the only trustworthy baseline until proven otherwise.
Flaws found:
- 7 ERRORs, all in `tests/test_ready_wiring_routes.py` — needs isolation to confirm collection-time vs runtime, and whether it's test-order-dependent or fails standalone too.
- 26 FAILED, several clustered: `test_04_websockets.py` (6 of them), `test_main_route_authorization_parity.py` (5 of them), `test_06_regression.py` (4 of them) — clusters suggest shared root causes, not 26 independent bugs.
- Root cause candidate spotted directly in output: `AttributeError: module 'bcrypt' has no attribute '__about__'` inside `passlib/handlers/bcrypt.py` — a known passlib/bcrypt version incompatibility (passlib reads `bcrypt.__about__.__version__`, removed in newer bcrypt releases). This is an environment/dependency-pin issue, not necessarily a PubCast logic bug. Needs confirmation of blast radius before calling it the cause of the auth-cluster failures.

---

### 2026-08-30 — Test-order pollution: root cause, fix, verification (Phase 1, Task 1.1)
Checked: the 7 ERRORs from the baseline entry above, isolated via binary search over the real pytest collection order (64 files; minimal reproducing prefix = 31 files + tests/test_ready_wiring_routes.py).
Verdict: ✅ VERIFIED WORKING (root-caused and fixed; full-suite re-run below)

Evidence — root cause #1 (RecursionError):
`thinking_context.mount()` (thinking_context/mount.py) is documented as a single, one-time call at app-build time, but `main.py`'s step 9 called it from *inside* `lifespan()`, which itself re-executes in full on every `TestClient(main.app)` open against the same app singleton (confirmed by isolated repro script, not assumption — see below). `mount()` unconditionally does `_existing = app.router.lifespan_context; ...; app.router.lifespan_context = new_wrapper_around(_existing)`. Called from inside a lifespan that re-enters itself, this wraps the lifespan around its own previously-installed wrapper on every boot, one layer deeper each time, with no unwind. Reproduced directly, outside pytest's traceback collapsing:
```
$ python3 repro_recursion.py   # 5x open/close on the same imported main.app, no re-import
iteration 1 "shutting down Jeremy" count: 0(baseline)
iteration 2: 1  iteration 3: 2  iteration 4: 3  iteration 5: 4   <- unbounded linear growth
```
Given the real suite triggers hundreds of cumulative TestClient opens (fixtures + ad-hoc per-test TestClient use across 555+ tests), this crosses Python's default recursion limit (1000) — the exact `RecursionError: maximum recursion depth exceeded` seen in tests/test_ready_wiring_routes.py's setup.

Evidence — root cause #2 (same mechanism, broader): the *entire* 12-step boot in `main.py`'s `lifespan()` was re-running on every re-entrant open, not just step 9 — including every `application.include_router(...)` call. This is the confirmed cause of `tests/test_02_routing.py::test_no_duplicate_http_routes` failing under full-suite order (duplicate route registration) and of a PosixPath internal-cache corruption (`AttributeError: 'PosixPath' object has no attribute '_str'/'_drv'` → `RecursionError` in `pathlib.py`) surfacing through repeated `PerformanceManager(policy_path=Path("system_policy.json"))` construction, which produced the `test_main_route_authorization_parity.py` cluster (5 failures).

Fix (main.py):
1. Guarded the `tc_mount()` call site at step 9 with `if getattr(application.state, "thinking_context", None) is not None: skip`.
2. Root fix: guarded the entire `lifespan()` body with `if getattr(application.state, "_pubcast_booted", False): yield; return` at the top, `application.state._pubcast_booted = True` immediately after. First entry per app object does the real 12-step boot; every subsequent entry on the same app singleton is a no-op yield. `application.state` persists on the app object across separate lifespan executions (Starlette does not reset it), confirmed empirically, not assumed.

Verification, before → after, same exact combo (31-file real-collection-order prefix + tests/test_ready_wiring_routes.py):
```
before: 19 failed, 413 passed, 7 errors
after:  16 failed, 423 passed, 0 errors
```
`test_main_route_authorization_parity.py`'s 5 failures gone in this combo (PerformanceManager/Path corruption mechanism eliminated). Isolated repro re-run at 20 iterations: full 12-step boot log ("— PubCast AI v5.6 starting —") now appears exactly 1 time across 20 opens (`grep -c` on raw output), not 20 times.

Full-suite re-run, before → after:
```
before: 555 passed, 26 failed, 2 skipped, 10 warnings, 7 errors
after:  566 passed, 22 failed, 2 skipped, 10 warnings, 0 errors
```
+11 passed, -4 failed net, -7 errors (7 eliminated, not hidden — accounting checked: 555+26+7=588, 566+22=588, consistent).

Order-independence check on the remaining 22 failures: ran the 11 files containing all 22 failures together, isolated from the other ~53 files in the suite. All 22 reproduced exactly, nothing more, nothing less, in 7.37s. This means the remaining 22 are NOT test-order artifacts — they're genuine, standalone, reproducible bugs, a different category of work than what this entry covers.

Flaws found (side effect of the fix, not swept under the rug):
- `tests/test_frontend_startup_contracts.py::test_startup_boots_surface_voxel_and_studio_without_constructor_failures` now fails where it previously passed (confirmed absent from the original baseline's FAILED list). It opens its own local `TestClient(main.app)` and asserts on `caplog` text from *that* open, assuming every open triggers a fresh full boot with fresh logs. That assumption was already false in production (a real server boots once) and is now correctly false in tests too. Its two sibling tests in the same file (`test_studio_and_voxel_endpoints_are_live_after_startup`, `test_studio_preflight_and_emergency_save_routes_work`) check real post-boot functional state instead of scraping fresh boot logs, and both still pass — confirming the underlying systems (surface manager, voxel stack, studio control) are genuinely healthy; only this one test's *method* of checking is now stale.
  This is a genuine fork, not resolved here: either (a) restructure main.py's boot steps to persist per-step outcomes into `application.state` so any test can check real state regardless of boot timing (broader change, touches ~4 of the 12 steps), or (b) rewrite this one test to check real state/endpoints like its siblings do (smaller, but changes a test's method, not just production code). Flagging rather than picking one unasked, per the standing rule on forks.
- Pre-existing, unrelated bug confirmed via direct code read, not guessed: `tests/test_02_routing.py::test_no_duplicate_http_routes` fails because `('/api/inference/tts', 'POST')` is genuinely registered twice in the real route table — present even within a single clean boot, unrelated to the lifespan-repetition mechanism above. Not investigated further this session.
- Remaining 22 failures, by file (not yet investigated beyond the order-independence check above): test_02_routing.py (1, above), test_04_websockets.py (7), test_06_regression.py (4, likely same underlying mechanism as the websocket cluster — not confirmed), test_alex_little_one_disabled.py (1), test_cast_staged_integration.py (1), test_frontend_contract_compat.py (1), test_frontend_startup_contracts.py (1, above), test_memory_systems.py::test_bridge (1, `TypeError` on `AlexJeremyBridge` construction), test_no_user_audit.py (1), test_pubcast_smoke.py (3), test_three_solution_rounds_auth_foundation.py::test_auth_login_verifies_password_and_role (1 — likely the passlib/bcrypt `AttributeError: module 'bcrypt' has no attribute '__about__'` spotted directly in the original baseline's raw output; not yet confirmed as the cause of this specific test).

---

### 2026-08-31 — Correction to the previous entry: two claims that were stated with more confidence than the evidence supported

**Correction 1 — the PosixPath cluster was not a second bug.**
The previous entry stated the `test_main_route_authorization_parity.py` cluster was caused by "a PosixPath internal-cache corruption... surfacing through repeated PerformanceManager(...) construction" — framed as a second, distinct mechanism from the ThinkingContext lifespan-wrapping recursion. That was not verified; it was inferred from the cluster disappearing after the same fix that addressed the lifespan-wrapping bug, which is correlation, not a traced mechanism.
Re-investigated directly: reconstructed the original (pre-fix) main.py in isolation, ran repeated boots with `DATA_DIR` monkeypatched fresh each time (matching what the real test file does), recursion limit raised so a real error surfaces before Python's default ceiling silently reshapes the traceback.
Evidence:
```
RecursionError on boot #39
traceback depth: 1998 frames; last 20 frames all alternating:
   routing.py merged_lifespan 240
   contextlib.py __aenter__ 210
```
No PosixPath AttributeError anywhere in this reproduction — a plain RecursionError inside Starlette's own lifespan-nesting chain, the exact same mechanism already fixed. This is strong evidence the PosixPath flavor originally seen was the *same* unbounded-nesting recursion, just crossing Python's recursion ceiling at a different point in the call stack under pytest specifically (pytest's own fixture/assertion-rewriting overhead consumes additional stack depth per accumulated layer, shifting exactly which function call is on top when the ceiling hits — in that case, pathlib's lazy `_str`/`_drv` property computation, which uses AttributeError internally as its own cache-miss signal and produced a locally-confusing but mechanistically-unremarkable traceback).
Verdict: ❓ UNVERIFIED → downgraded further to "very likely the same single root cause, not a second bug" — I have not reproduced the exact PosixPath traceback itself, only the same-depth same-mechanism RecursionError via a different call path. Do not treat this as fully closed; if the auth-parity cluster reappears in any future full-suite run, re-open it as a possible second bug rather than assuming it's covered by the existing fix.

**Correction 2 — the bcrypt claim named the wrong failure inside the right neighborhood.**
Previously stated (in conversation, not yet in the ledger) that `tests/test_three_solution_rounds_auth_foundation.py::test_auth_login_verifies_password_and_role` was "almost certainly" caused by `AttributeError: module 'bcrypt' has no attribute '__about__'`, based on seeing that error once in unrelated output and pattern-matching it to an untriaged test. Isolated the actual test and read its real traceback.
Evidence:
```
$ pytest tests/test_three_solution_rounds_auth_foundation.py::test_auth_login_verifies_password_and_role -q
WARNING passlib.handlers.bcrypt: (trapped) error reading bcrypt version
  AttributeError: module 'bcrypt' has no attribute '__about__'      <- present, but caught/trapped by passlib itself, not the failure
...
E   ValueError: password cannot be longer than 72 bytes, truncate manually if necessary
    at passlib/handlers/bcrypt.py:655, inside passlib's own detect_wrap_bug() backend self-test
1 failed in 1.81s
```
The `__about__` AttributeError is real but harmless — passlib traps it internally and falls back to a version probe. The actual failure is a second, different passlib/bcrypt incompatibility: passlib's own internal self-test constructs a >72-byte probe string, which the installed bcrypt version now rejects with a hard `ValueError` instead of the behavior passlib's self-test expects.
Verdict: ✅ VERIFIED — root cause confirmed by direct traceback, not inferred. Both are real passlib/bcrypt version-compatibility problems; they are not the same failure, and only the second one is what's breaking this specific test.

Standing note for future sessions: the previous entry's two claims were stated with the same confident, evidenced-looking phrasing as the verified fixes in that same entry, which made an unverified inference and a verified fix textually indistinguishable at a glance. Watch for that pattern specifically, not just for the presence of hedge words.

---

### 2026-08-31 — Round 1: websocket cluster (test_04_websockets.py, test_06_regression.py)
Checked: all 7 test_04_websockets.py failures + the 4 test_06_regression.py failures, first confirmed pre-existing (present in the original pre-fix baseline, not caused by the lifespan fix). Initially suspected one shared root cause; verified individually instead of assuming.
Verdict: mixed — see below, three distinct findings, none silently fixed.

**Finding 1 — ✅ VERIFIED, real, provable-fix candidate.** `hub.connect()` (modules/hub.py:55) broadcasts `{"type": "presence", ...}` to the whole room, including the client that just connected, before that client has sent anything. Four tests (`test_ws_room_connects`, `test_ws_room_chat_message`, `test_ws_room_unknown_type_returns_error`, `test_ws_room_invalid_json_does_not_crash`) connect, send one message, and call `receive_json()` exactly once expecting the response to their own message — they get the presence broadcast instead. Reproduces standalone, alone, first test in a fresh process — not test-order pollution. Confirmed via direct traceback: `AssertionError: Hub returned unexpected type: presence`.
Not fixed yet: whether the correct fix is (a) don't echo presence back to the connecting client itself, only to others already in the room, or (b) tests should drain the presence message before asserting, is a design call, not a bug with one obvious direction — presence-on-connect may be intentional. Flagging rather than picking.

**Finding 2 — ❓ UNVERIFIED, genuine fork, NOT resolved.** `test_ws_unity_not_treated_as_hub_room` and `test_ws_studio_not_treated_as_hub_room` connect to `/ws/unity` and `/ws/studio` and fail because those requests are actually being matched by the generic `/ws/{room}` catch-all (with room="unity"/"studio"), not by dedicated handlers. Traced precisely, not assumed:
- main.py's real, live registrations (confirmed via `@app.websocket(...)` grep, cross-checked against AST parsing to rule out docstring false-positives) are `/unity/ws/{client_id}` and `/studio/ws` — neither matches what the tests request.
- `modules/studio_websocket.py` contains `@app.websocket("/ws/studio")` twice, but AST-parsed: both are inside docstrings/example-usage strings, not live code — confirmed zero real decorators in that file. It documents `/ws/studio` as the intended integration convention; main.py's real registration diverges from its own dependency's documented contract.
- For unity: no second source anywhere in the codebase corroborates `/ws/unity` — main.py is internally consistent (`/unity/ws/{client_id}` in both the live route and its own log messages at boot). Only the test expects `/ws/unity`, with nothing else backing it up.
- This asymmetry matters and is stated precisely rather than treating both the same: studio has two independent sources agreeing against main.py's one; unity has only the test against everything else. I do not know from the code alone whether either "wrong" path is actually a live, real-world integration point (a real Unity client, a real Studio Control frontend) that would break if renamed. Not resolved. Needs a decision on which path is authoritative for each, not a guess.
`test_reg001_ws_unity_not_shadowed_by_ws_room` and `test_reg001_ws_studio_not_shadowed_by_ws_room` in test_06_regression.py are very likely the same finding (matching names, matching symptom) — not independently re-traced this round; treat as the same open fork, not two more bugs.

**Finding 3 — ❓ UNVERIFIED, not traced this round.** `test_ws_rooms_are_isolated` fails on `assert 'history' == 'chat'` — a client receives a `"history"`-typed message where a `"chat"` echo was expected. Not yet traced to a specific source (candidate: `tc.watch_room()`, called right after `hub.connect()`, may also emit an initial message the test doesn't drain — not confirmed). Distinct from Finding 1's `"presence"` symptom, not assumed to be the same mechanism.

Remaining 2 of the 4 test_06_regression.py failures (`test_reg002_lighting_apply_has_hub_null_guard`, `test_reg003_chat_callback_guards_purfluous_user`) not investigated this round.

---

### 2026-08-31 — Round 2: bcrypt/passlib version incompatibility (requirements.txt)
Checked: `tests/test_three_solution_rounds_auth_foundation.py::test_auth_login_verifies_password_and_role`, root-caused in the prior correction entry to passlib 1.7.4's `detect_wrap_bug()` self-test failing against bcrypt 5.0.0's stricter >72-byte input handling.
Verdict: ✅ VERIFIED WORKING (fixed and confirmed, not just diagnosed)
Evidence:
```
$ python3 -c "import bcrypt; print(bcrypt.__version__)"   # before
5.0.0
$ pip install --break-system-packages -q "bcrypt<4.0.0"
$ python3 -c "import bcrypt; print(bcrypt.__version__)"   # after
3.2.2
$ pytest tests/test_three_solution_rounds_auth_foundation.py::test_auth_login_verifies_password_and_role -q
1 passed, 1 warning in 1.47s
```
Full-suite re-run to check for regressions from the downgrade before calling it clean, not assumed safe:
```
before this round: 22 failed, 566 passed, 2 skipped, 0 errors
after this round:  21 failed, 567 passed, 2 skipped, 0 errors
```
Only the auth-login test changed status; no new failures introduced.
Made durable: added `bcrypt<4.0.0` to requirements.txt (not just this container's installed packages), with the evidence inline as a comment. Reinstalled from the patched `requirements.txt` itself (`pip install -r requirements.txt`) and re-confirmed `bcrypt.__version__ == 3.2.2` from that install, not carried over from the earlier manual `pip install` — fixing my own earlier lapse of treating "cp'd a file" as equivalent to "verified the actual artifact."

---

### 2026-08-31 — Round 3: test_memory_systems.py::test_bridge
Checked: `TypeError: AlexJeremyBridge.__init__() got an unexpected keyword argument 'alex'`.
Verdict: ❌ CONFIRMED BROKEN — but not a small fix; the test exercises an API that no longer exists, not a renamed/misspelled argument.
Evidence:
- Real, live `AlexJeremyBridge.__init__` (modules/alex_jeremy_bridge.py:26) takes only `data_dir: Path`. It has no `alex` or `jeremy` parameters at all — internally it builds and owns its own `AlexCore` instances per-user via `alex_for(user_id)`, and integrates with Jeremy through a packet-based pattern (`build_entry_packet(...)`, `signal_from_jeremy(...)`), not by holding direct references to externally-constructed alex/jeremy objects.
- The test constructs `bridge = AlexJeremyBridge(alex=alex, jeremy=jeremy)` — the old, apparently pre-refactor calling convention.
- The test imports `Alex` from `modules.alex_memory`; the real bridge imports and uses `AlexCore` from `modules.alex_core` — two different classes in two different modules. Confirmed via `main.py`: the live application imports and wires up `AlexCore` (modules/alex_core.py) exclusively; `alex_memory.py`'s `Alex` is never referenced by main.py.
- Checked before concluding `alex_memory.py` is dead code (it is not, and I am not claiming that): `grep` across the whole tree shows `modules/memory_ingestor.py` also imports from `modules.alex_memory`, so `Alex` itself has a real, live usage path through a different integration point than this test exercises. What's stale is narrower and more precise than "the whole file tests dead code": specifically, this test's assumption that `AlexJeremyBridge` accepts `alex=`/`jeremy=` directly at construction time — that calling convention is gone from the real class, regardless of whether `Alex` remains alive elsewhere.
Not fixed: rewriting this test to match the current `AlexJeremyBridge`/`AlexCore` packet-based contract means writing new test logic against a redesigned subsystem, not patching a call site — out of this round's scope per the standing rule (small provable fixes get fixed inline; larger gaps get logged, not silently built). Flagging for a decision: confirm whether `test_bridge` should be rewritten against the current bridge API, or whether it's testing an integration path that's been intentionally superseded and the test should be retired.
