# PubCast Audit — Session Handoff

Written at the end of a working session, for whoever (human or Claude) picks
this up next. Goal: lose nothing. Read this fully before touching code.

---

## 1. How to use this document

This is a continuation of a continuous audit governed by three documents
Josie originally provided:

- `PubCast_Continuous_Audit_Prompt.md` — the method. Re-read it, especially
  the ground rules: only call something working if you personally ran it and
  are showing the exact command + literal output; classify every finding as
  ✅ VERIFIED WORKING / ❌ CONFIRMED BROKEN / ❓ UNVERIFIED; never trust a
  filename, docstring, or old status note — open the file and read the real
  code; keep `AUDIT_LEDGER.md` updated as you go, append-only, never
  overwrite a past entry.
- `PubCast___PubPartner___2i.md` — the architecture / scope: what PubCast,
  PubPartner, and 2i are, how they're supposed to integrate, what's deferred
  vs wired.
- `PUBCAST_CHAPTER_RULE_REVIEW.md` — the working constraints: small provable
  fixes get fixed inline with before/after proof; large gaps get logged as a
  scoped flaw, not silently built; genuine forks get asked about, not
  guessed at.

If those three aren't already in the new conversation's context, re-upload
them — this handoff assumes their rules are still in force, it doesn't
restate them in full.

**Josie's standing preferences that govern how to work with her** (carry
these forward regardless of what else is in context): never lie, omit, or
spin — she needs actual facts; never alter her own words without explicit
permission; production-grade code only — the bar is "a fresh CS grad reads
it and thinks I'll never write that good"; PowerShell 5-compatible syntax
when anything touches her shell; read the full codebase before writing any
code; the three-solutions rule — consider at least three approaches before
committing to one; before building anything new, check whether a more
advanced version already exists elsewhere in her repos and adapt it rather
than starting fresh.

---

## 2. Where the code actually lives

Repo: `https://github.com/whatsupjosie/Pubcaast-Breaking-Dawn`

Real working code, inside that repo, at:
`pubcast_breaking_dawn/WORKING_PROGRAM/{pubcast, pubpartner, 2i-backend}`

This session's container path was `/home/claude/INTEGRATED_BUILD/pubcast` —
that path will **not** persist into a new conversation. A new session needs
to either re-clone the repo and re-apply the two fixes below (diffs
included), or start from the attached, already-fixed `main.py` and
`requirements.txt`.

Python 3.12.3. `fastapi==0.141.1`, `pytest==9.1.1` as installed this session.
Install with `pip install --break-system-packages -r requirements.txt -r
requirements-dev.txt` (the `--break-system-packages` flag is required in
this container's Python environment).

---

## 3. Current verified state

Real, from a full-suite run at the end of this session, command and output
both shown, not carried over from an earlier claim:

```
$ python3 -m pytest tests/ -q --no-header
21 failed, 567 passed, 2 skipped, 10 warnings in 35.56s
```

At the start of this session, the real (re-measured, not assumed) baseline
was:

```
555 passed, 26 failed, 2 skipped, 10 warnings, 7 errors in 38.58s
```

Net this session: +12 passed, -5 failed, -7 errors (errors eliminated, not
hidden — the accounting was checked: 555+26+7=588, 567+21+0=588, consistent
both times).

---

## 4. Fixes made this session — verified, durable, already in the attached files

### Fix 1 — Lifespan idempotency (`main.py`)

**The bug:** `main.py`'s entire 12-step boot sequence (the `lifespan()`
async context manager, ~760 lines, registered as the app's ASGI lifespan)
was re-executing in full on every single `TestClient(main.app)` open against
the same app singleton — not once per process, which is what a real
production server does. Two concrete, proven consequences:

1. Step 9 calls `thinking_context.mount()`, which is documented as a single,
   one-time call but is not idempotent: it captures whatever is currently
   set as `app.router.lifespan_context` and wraps a new lifespan around it.
   Called from inside a lifespan that re-enters itself, this nests the
   lifespan around its own previous wrapper on every re-entrant boot, one
   layer deeper each time, unbounded. Proven outside pytest, isolated:
   repeated open/close on the same imported `main.app`, no re-import, showed
   `"shutting down Jeremy"` firing 0, 1, 2, 3, 4 times per close — linear,
   unbounded growth. Enough accumulated opens across the real 555+ test
   suite eventually exceeded Python's default recursion limit (1000) —
   this was the direct cause of 7 ERRORs in `tests/test_ready_wiring_routes.py`.
2. Every `application.include_router(...)` call inside the boot also
   re-ran on every re-entrant boot — confirmed cause of
   `test_02_routing.py::test_no_duplicate_http_routes` failing under
   full-suite order (though see §7 below — that test is *still* failing,
   for a second, unrelated reason: a genuinely duplicate route declaration).
   `PerformanceManager` was also rebuilt from scratch on every re-entrant
   boot; this was very likely (see the correction in §6) the same single
   recursion-depth mechanism surfacing at a different point in the call
   stack under pytest specifically, not a second distinct bug — it
   produced a 5-test cluster in `test_main_route_authorization_parity.py`
   that is now gone.

**The fix:** two additive guards in `main.py`, zero deletions of existing
logic, ~90 lines total (mostly comments explaining why, per Josie's
production-grade standard):

1. A narrow guard at step 9's `tc_mount()` call site, checking
   `application.state.thinking_context`.
2. The real fix: a guard at the very top of `lifespan()` itself —
   `if getattr(application.state, "_pubcast_booted", False): yield; return`
   — followed by `application.state._pubcast_booted = True`.
   `application.state` persists on the app singleton across separate
   lifespan executions (Starlette does not reset it between boots,
   confirmed empirically not assumed), so it's the correct place to mark
   "already booted." First entry per app object does the real 12-step boot;
   every subsequent entry on the same app singleton is a no-op yield.

**Verification, before → after, same real commands:**
```
Isolated repro, 20 repeated opens: "— PubCast AI v5.6 starting —" now
appears exactly 1 time (grep -c on raw output), not 20 times.

Exact combo that originally produced 7 errors (31-file real-collection-order
prefix + tests/test_ready_wiring_routes.py):
  before: 19 failed, 413 passed, 7 errors
  after:  16 failed, 423 passed, 0 errors

Full suite:
  before: 555 passed, 26 failed, 2 skipped, 7 errors
  after:  566 passed, 22 failed, 2 skipped, 0 errors

Order-independence check (important — confirms the remaining failures are
real bugs, not more hidden pollution): ran just the 11 files containing all
22 remaining failures, isolated from the other ~53 files. All 22 reproduced
exactly, nothing more, nothing less, in 7.37s.
```

A known, honest side effect of this fix — not swept under the rug — is
documented in §7, Fork 3.

Full diff attached as `main_py_fix.diff`. Fixed file attached as `main.py`.

### Fix 2 — bcrypt/passlib version pin (`requirements.txt`)

**The bug:** `tests/test_three_solution_rounds_auth_foundation.py::test_auth_login_verifies_password_and_role`
failed. The traceback shows an `AttributeError: module 'bcrypt' has no
attribute '__about__'` — but that is a **trapped, harmless** warning
passlib catches internally, not the actual failure (this was gotten wrong
once this session — see the correction in §6). The real failure is a
different bcrypt incompatibility: passlib 1.7.4's own internal
`detect_wrap_bug()` backend self-test constructs a >72-byte probe string,
which bcrypt 5.0.0 now rejects with a hard `ValueError` instead of the
older, more permissive behavior passlib's self-test assumes. passlib has
had no release since 2020 and predates bcrypt's breaking changes.

**The fix:** pinned `bcrypt<4.0.0` in `requirements.txt`, landing on 3.2.2,
with the evidence written inline as a comment so the reasoning survives a
fresh install, not just this session's memory.

**Verification:**
```
$ python3 -c "import bcrypt; print(bcrypt.__version__)"   # before: 5.0.0
$ pip install --break-system-packages -q "bcrypt<4.0.0"
$ python3 -c "import bcrypt; print(bcrypt.__version__)"   # after: 3.2.2
$ pytest tests/test_three_solution_rounds_auth_foundation.py::test_auth_login_verifies_password_and_role -q
1 passed, 1 warning in 1.47s
```
Full suite re-run afterward to check for regressions from the downgrade,
not assumed safe: 21 failed / 567 passed / 0 errors — only the auth-login
test changed status, nothing else moved.
Reinstalled from the patched `requirements.txt` itself afterward and
re-confirmed `bcrypt.__version__ == 3.2.2` from that install, not carried
over from the earlier manual `pip install` — this closes a real lapse from
earlier in the session (see §6).

Fixed file attached as `requirements.txt`.

---

## 5. Corrections made this session — read this, it's a calibration warning

Two claims were stated with the same confident, evidenced-looking phrasing
as the verified fixes in the same ledger entry, which made an unverified
inference and a verified fix textually indistinguishable at a glance. Both
were caught and corrected in the ledger, append-only, not silently edited
away:

1. **The PosixPath claim.** Originally stated as "a PosixPath internal-cache
   corruption... surfacing through repeated PerformanceManager(...)
   construction" — framed as a second, distinct mechanism from the
   ThinkingContext lifespan-wrapping recursion. That was inferred from
   correlation (the cluster disappeared after the same fix), not traced.
   Re-investigated directly: reconstructed the original pre-fix code,
   forced hundreds of repeated boots with the recursion ceiling raised so a
   real error would surface intact — got a plain `RecursionError` inside
   Starlette's own lifespan-nesting chain at boot #39, no pathlib involved.
   Very likely the same single root cause landing on a different stack
   frame due to pytest's own overhead, not a second bug — but the exact
   PosixPath traceback itself was never reproduced, so this stays flagged
   as "very likely," not "confirmed." **If the `test_main_route_authorization_parity.py`
   cluster reappears in any future run, re-open it as a possible second bug
   rather than assuming Fix 1 covers it.**

2. **The bcrypt claim.** Said "almost certainly" the `__about__`
   AttributeError caused the auth-login test failure, based on seeing that
   error once in unrelated output and pattern-matching it to an untriaged
   test. Isolated the test and read the real traceback — wrong mechanism,
   right neighborhood (see Fix 2 above for the actual cause).

**The pattern to watch for going forward:** confident phrasing does not mean
verified. When re-reading the ledger, don't trust a claim's tone — check
whether it cites a command + literal output, or an inference from
correlation. If the latter, treat it as ❓ UNVERIFIED regardless of how it
reads.

---

## 6. Open forks — Josie's call, not something to resolve unilaterally

These came up during Round 1 and Round 3 of this session's debugging.
Genuine forks per the audit rules: "hit a fork you can't resolve from the
code alone, stop and ask." Do not silently pick a direction on any of these
in a future session without checking with Josie first — a wrong guess here
could rename a path or rewrite a test against a real, working integration
neither of us can see from the code alone.

### Fork 1 — Studio and Unity websocket paths

`tests/test_04_websockets.py::test_ws_unity_not_treated_as_hub_room` and
`::test_ws_studio_not_treated_as_hub_room` (plus their near-duplicates
`test_reg001_ws_unity_not_shadowed_by_ws_room` /
`test_reg001_ws_studio_not_shadowed_by_ws_room` in `test_06_regression.py`)
fail because `/ws/unity` and `/ws/studio` are being caught by the generic
`/ws/{room}` handler instead of dedicated ones.

Real, live registrations in `main.py` (confirmed via grep, cross-checked
with AST parsing to rule out docstring false-positives):
`/unity/ws/{client_id}` and `/studio/ws` — **neither matches what the
tests, or the studio module's own docs, expect.**

The evidence is asymmetric — stated precisely, not flattened into "both
paths are wrong the same way":

- **Studio:** two independent sources agree against `main.py`'s one:
  the test file expects `/ws/studio`, *and* `modules/studio_websocket.py`'s
  own docstring documents `/ws/studio` as the intended integration
  convention. `main.py` alone uses `/studio/ws`.
- **Unity:** only the test expects `/ws/unity`. `main.py` is internally
  consistent everywhere else — the live route, and its own boot-time log
  messages, both agree on `/unity/ws/{client_id}`. Nothing else in the
  codebase corroborates `/ws/unity`.

**What's needed:** confirm with Josie whether either currently-registered
path (`/studio/ws`, `/unity/ws/{client_id}`) is a real, live integration
point some other client already depends on (a Unity build, a Studio Control
frontend). If not, the studio case leans toward `/ws/studio` being correct
and `main.py` having drifted; the unity case has no such lean — it may
simply be a stale test.

### Fork 2 — `test_bridge` / `AlexJeremyBridge`

`tests/test_memory_systems.py::test_bridge` fails with
`TypeError: AlexJeremyBridge.__init__() got an unexpected keyword argument 'alex'`.

Confirmed via reading the real class (`modules/alex_jeremy_bridge.py`): the
constructor now takes only `data_dir: Path`. It internally owns its own
`AlexCore` instances per-user (`alex_for(user_id)`) and integrates with
Jeremy through a packet-based pattern (`build_entry_packet(...)`,
`signal_from_jeremy(...)`), not by holding direct references to
externally-constructed `alex`/`jeremy` objects the way the test assumes.

The test also imports `Alex` from `modules.alex_memory`, a different class
than the `AlexCore` (from `modules.alex_core`) the real bridge uses.
Checked before concluding anything broader: `modules/alex_memory.py` is
**not** dead code — `modules/memory_ingestor.py` also imports from it, so
`Alex` has a real, live usage path elsewhere. What's actually stale is
narrower: specifically this test's assumption that `AlexJeremyBridge`
accepts `alex=`/`jeremy=` directly at construction.

**What's needed:** confirm with Josie whether `test_bridge` should be
rewritten against the current packet-based `AlexJeremyBridge`/`AlexCore`
contract, or whether it's testing an integration path that was
intentionally superseded and the test should just be retired.

### Fork 3 — `test_frontend_startup_contracts.py`, a side effect of Fix 1

`test_startup_boots_surface_voxel_and_studio_without_constructor_failures`
now fails where it previously passed (confirmed absent from the original
baseline's FAILED list — this is a genuine, honest consequence of Fix 1,
not swept under the rug). It opens its own local `TestClient(main.app)` and
asserts on `caplog` text captured from *that specific open*, assuming every
open triggers a fresh full boot with fresh logs. That assumption was
already false in production (a real server boots once) and is now correctly
false in tests too — if any earlier test already triggered the one real
boot for the session, this test's own open is a no-op and there's nothing
in `caplog` to check.

Its two sibling tests in the same file
(`test_studio_and_voxel_endpoints_are_live_after_startup`,
`test_studio_preflight_and_emergency_save_routes_work`) check real
post-boot functional state via actual endpoint calls instead of scraping
fresh boot logs, and both still pass — confirming the underlying systems
(surface manager, voxel stack, studio control) are genuinely healthy; only
this one test's *method* of checking is now stale.

**What's needed — this is a real design fork, not a bug with one obvious
fix:**
- Option A (smaller): rewrite this one test to check real post-boot state,
  matching its own siblings' pattern, instead of scraping fresh logs.
- Option B (larger, more robust): restructure `main.py`'s boot steps to
  persist per-step outcomes into `application.state` (e.g.
  `application.state.boot_step_results = {...}`), so any test can check
  real state regardless of *when* in the session the one real boot
  happened — decouples this test (and any future one) from needing to
  personally trigger a fresh boot at all. Touches ~4 of the 12 steps.

Neither was picked this session — flagged per the standing rule on forks.

---

## 7. Full inventory of the remaining 21 failures

Verified real, current, from the full-suite run in §3. Grouped by
investigation status:

**Investigated this session, findings above:**
- `test_02_routing.py::test_no_duplicate_http_routes` — investigated in
  Round 1, but **not yet fixed**. Confirmed real and unrelated to the
  lifespan fix: `('/api/inference/tts', 'POST')` is genuinely registered
  twice in the real route table, present even within a single clean boot.
  Exact second registration site not yet located — see Probe 1 below.
- `test_04_websockets.py::test_ws_room_connects`,
  `::test_ws_room_chat_message`, `::test_ws_room_unknown_type_returns_error`,
  `::test_ws_room_invalid_json_does_not_crash` — Round 1, Finding 1
  (presence-echo). Real, provable-fix candidate, not yet fixed pending
  direction (see §6 is not the right fork for this one — this one doesn't
  need Josie's input the same way; it's a design choice about whether
  `hub.connect()` should echo presence to the connecting client itself, see
  Probe 3 below for a concrete next step).
- `test_04_websockets.py::test_ws_unity_not_treated_as_hub_room`,
  `::test_ws_studio_not_treated_as_hub_room` — Fork 1 above.
- `test_04_websockets.py::test_ws_rooms_are_isolated` — Round 1, Finding 3.
  `AssertionError: assert 'history' == 'chat'`. Not traced to a specific
  source. Candidate: `tc.watch_room()`, called right after `hub.connect()`
  in the websocket handler, may also emit an initial message the test
  doesn't drain — not confirmed. See Probe 3.
- `test_06_regression.py::test_reg001_ws_unity_not_shadowed_by_ws_room`,
  `::test_reg001_ws_studio_not_shadowed_by_ws_room` — very likely Fork 1,
  matching names and symptom, but **not independently re-traced** — treat
  as the same open fork, not confirmed as identical without checking.
- `test_memory_systems.py::test_bridge` — Fork 2 above.
- `test_frontend_startup_contracts.py::test_startup_boots_surface_voxel_and_studio_without_constructor_failures` —
  Fork 3 above.

**Not investigated at all this session:**
- `test_06_regression.py::test_reg002_lighting_apply_has_hub_null_guard`
- `test_06_regression.py::test_reg003_chat_callback_guards_purfluous_user`
- `test_alex_little_one_disabled.py::test_default_user_and_session_payloads_are_neutral_when_disabled`
- `test_cast_staged_integration.py::test_character_profile_aliases_resolve`
- `test_frontend_contract_compat.py::test_no_broken_static_api_refs_after_startup`
- `test_no_user_audit.py::test_avatar_compatibility_shim_exists_and_points_to_avatar_glow`
- `test_pubcast_smoke.py::test_inference_status_exposes_config`
- `test_pubcast_smoke.py::test_inference_status_handles_invalid_config_path`
- `test_pubcast_smoke.py::test_bot_crud_and_speak_endpoint`

---

## 8. Next three probes

Picked for a mix of quick-win confidence and genuine open threads, in
priority order. Each has a concrete starting command — don't re-derive
from scratch.

### Probe 1 — `test_02_routing.py::test_no_duplicate_http_routes` (highest confidence, likely quick)

Already root-caused to a genuine duplicate: `('/api/inference/tts', 'POST')`
registered twice in the real route table, confirmed present even within a
single clean boot (unrelated to the lifespan-repetition mechanism already
fixed). Not yet located precisely or fixed.

Start with:
```
grep -n '"/api/inference/tts"' main.py modules/*.py
```
Find both registration sites, read both handlers, determine which is the
real one (or whether they're genuinely redundant and one should be
deleted), fix, then re-run the specific test plus a full-suite regression
check before calling it done — same discipline as Fix 2 in §4.

### Probe 2 — `test_pubcast_smoke.py` (3 failures, unexamined, same file)

Three failures in one file often share a root cause — worth checking
together before assuming three separate bugs, same approach as Round 1
Finding 1 vs Findings 2/3.

Start with:
```
cd /home/claude/INTEGRATED_BUILD/pubcast  # or wherever the fresh clone lands
python3 -m pytest tests/test_pubcast_smoke.py -q --no-header
```
then read the real tracebacks for all three before touching any code.

### Probe 3 — Trace the `'history'` vs `'chat'` mechanism (`test_ws_rooms_are_isolated`)

Loose thread from Round 1, Finding 3. Worth closing because it's adjacent
to but distinct from the presence-echo finding (Finding 1) — tracing it
will confirm whether it's a second instance of the same undrained-message
pattern, or a genuinely separate issue.

Start with:
```
python3 -m pytest tests/test_04_websockets.py::test_ws_rooms_are_isolated -q --no-header
```
then check `tc.watch_room()` in `thinking_context/` for whether it emits
any message to the room on connect, the same way `hub.connect()` does for
`"presence"` — read the real code, don't assume the candidate is correct
just because it's plausible.

---

## 9. Suggestions for further tests / debugging beyond the three probes

**A regression test for Fix 1 itself.** Nothing currently guards against
someone re-introducing the non-idempotent lifespan pattern later (e.g. by
adding a new step to the boot sequence that assumes it only ever runs
once, the same mistake `tc_mount()` made). Suggest a test that explicitly
opens `TestClient(main.app)` multiple times against the same app object and
asserts the boot-sequence banner log appears exactly once — this would have
caught the original bug immediately and will catch a regression the same
way.

**An audit pass for other non-idempotent boot-time side effects.** Only the
side effects that happened to break a test were found and fixed this
session (ThinkingContext wrapping, router re-registration, PerformanceManager
reconstruction). The ~700-line boot sequence almost certainly has other
global-state mutations, file writes, or singleton assignments that are
technically also non-idempotent but happened not to surface as a visible
test failure — possibly because they're harmlessly overwritten on repeat,
or because nothing currently tests the specific thing they'd corrupt. Worth
a deliberate read-through of all 12 steps specifically asking "does this
assume it only runs once?" rather than waiting for more accidental
discoveries.

**A real risk worth naming plainly: silent state-bleed between currently-passing tests.**
Fix 1 means all tests using the session-scoped `client` fixture now share
one real boot's global state for the entire test session, not a fresh boot
each time. `test_frontend_startup_contracts.py` was *caught* being affected
by this because it turned a pass into a failure — visible. It is possible
other tests are now silently checking shared/stale state between each
other and still happen to show green, because nothing about their
assertions changed even though what they're actually observing did. This
is a real, non-obvious follow-up risk from the fix itself, not a hypothetical
concern to dismiss. Worth a scan of tests using the `client` fixture for
any that mutate global/room/hub state and might be read by a *later* test
expecting fresh state — not just the tests that currently fail.

**Four single-failure files, worth quick individual triage after the three
probes above:** `test_alex_little_one_disabled.py`,
`test_cast_staged_integration.py`, `test_frontend_contract_compat.py`,
`test_no_user_audit.py`. No shared-cause hypothesis for these yet — each
needs its own isolated traceback read, same method as every fix in this
session: command + literal output first, hypothesis second.

**Once Fork 1 (websocket paths) is resolved with Josie:** re-check
`test_06_regression.py::test_reg002_lighting_apply_has_hub_null_guard` and
`::test_reg003_chat_callback_guards_purfluous_user` — not yet confirmed
related to the same fork, don't assume they'll resolve automatically.

**Once Finding 1 (presence-echo) is resolved in whichever direction:**
consider whether the websocket connect-time message contract should be
written down explicitly somewhere (what a client should expect to receive,
and in what order, immediately after connecting) — right now nothing pins
this down, which is very likely why it drifted from what the tests assume
in the first place.

---

## 10. Files attached to this handoff

- `main.py` — the fixed file, Fix 1 applied, ready to drop into a fresh
  clone at `pubcast_breaking_dawn/WORKING_PROGRAM/pubcast/main.py`.
- `main_py_fix.diff` — clean diff of Fix 1 against the original, untouched
  repo copy.
- `requirements.txt` — the fixed file, Fix 2 applied.
- `AUDIT_LEDGER.md` — the full, real, append-only ledger for this session.
  This handoff summarizes it; the ledger has the complete evidence trail,
  including the two self-corrections in full. Continue appending to this
  same file in the next session — do not start a new one.
- `pytest_BEFORE_full_output.txt` — raw, complete output of the very first
  full-suite run this session (555/26/2/7).
- `pytest_AFTER_full_output.txt` — raw, complete output after Fix 1
  (566/22/2/0; note this predates Fix 2, which took it to 567/21/2/0 — the
  final number in §3 is the most current).
