from contextlib import asynccontextmanager

from fastapi import FastAPI

from pubcast_twin_engine_service import install_twin_engine_routes, mount_twin_engine


@asynccontextmanager
async def lifespan(app: FastAPI):
    bridge = getattr(app.state, "renderer_bridge", None)
    renderer = getattr(app.state, "renderer", None)
    await mount_twin_engine(app, bridge=bridge, renderer=renderer)
    try:
        yield
    finally:
        service = getattr(app.state, "twin_engine", None)
        if service is not None:
            await service.shutdown()


app = FastAPI(lifespan=lifespan)
install_twin_engine_routes(app)
