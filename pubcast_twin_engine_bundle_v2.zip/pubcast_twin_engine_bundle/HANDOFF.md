# PubCast Twin Engine Bundle — Accurate Handoff

## What this bundle is

This bundle is **not** a finished PubCast engine and it does **not** prove end-to-end rendering.

What it **is**:
- a **clean engine spine** for the PubCast twin-engine path
- a **mountable backend subsystem** intended to be hosted by the real PubCast `main.py`
- a **canonical virtual camera state layer** so camera behavior is not scattered across unrelated handlers
- an **honest health/status model** that can say `disconnected`, `degraded`, or `ready` without lying
- a **starter API surface** for scene and camera control through `/api/twin/*`

In plain English: this bundle is the beginning of turning the twin-engine from a concept or oversized integration blob into a real, contained service that the host app can mount, inspect, and grow.

---

## The intention behind this work

The main intention was to stop PubCast's engine work from collapsing into one giant speculative file that tries to do everything at once.

The design choice here is deliberate:
- **`main.py` remains the host and lifecycle owner**
- the twin-engine becomes a **subsystem**, not a second app
- the virtual camera gets a **single source of truth**
- bridge and renderer integrations are treated as **optional but reportable dependencies**
- the engine must **fail honestly** when the renderer or bridge is absent instead of pretending to be alive

That means this bundle is aimed at the real near-term goal:

> Get PubCast to a point where one mounted engine service can load one scene, switch one camera, report its real status, and be extended without chaos.

This is intentionally a **proof-oriented architecture step**, not a feature dump.

---

## What is included

### 1. `pubcast_twin_engine_service.py`
This is the main file in the bundle.

It contains:
- `TwinEngineMode`
  - `disconnected`
  - `degraded`
  - `ready`
- `CameraTransition`
  - `cut`
  - `dissolve`
  - `push`
  - `orbit`
- `Vec3`
- `VirtualCameraState`
- `TwinEngineService`
- `mount_twin_engine(app, bridge=..., renderer=...)`
- `twin_engine_status(app)`
- `install_twin_engine_routes(app)`

Core behavior implemented:
- startup checks for bridge and renderer
- health reporting
- safe shutdown
- default camera seeding
- scene selection
- active camera switching
- camera pose updates
- telemetry ingest hook
- generic command handling
- FastAPI route installation for `/api/twin/*`

### 2. `MAIN_PY_PATCH_EXAMPLE.py`
This is a minimal integration example showing the intended mounting pattern:
- create/load the FastAPI app
- mount the twin-engine in lifespan
- shut it down cleanly on exit
- install twin-engine routes

This file is **not** a patch automatically matched to your real `main.py`.
It is a reference pattern meant to be adapted into the real host app.

### 3. `pubcast_twin_engine_demo.py`
A runnable demo using dummy bridge and renderer classes.

Purpose:
- prove the service boots
- prove it can load a scene
- prove it can activate a camera
- prove it can update camera pose
- prove telemetry can push the service into a ready state

This is a behavior demo, not a production integration.

### 4. `test_pubcast_twin_engine_service.py`
Unit tests for the service.

Current coverage:
- startup to ready mode with dummy bridge and renderer
- camera activation sends bridge command
- disconnected mode stays honest when nothing is attached

### 5. `MANIFEST.md`
A clean file index for the bundle.

---

## What this bundle currently does well

### A. It creates a real engine boundary
Before this, the twin-engine concept risked being "everything goes everywhere."

Now there is a defined service boundary:
- internal camera state lives here
- scene/camera commands land here
- bridge commands originate here
- health truth is reported here

That is a meaningful structural improvement.

### B. It gives the virtual camera a canonical home
The camera is no longer just an idea or implied state spread across handlers.

`VirtualCameraState` now captures:
- camera id
- name
- position
- rotation
- fov
- target
- active state
- transition type
- update time

This matters because the virtual camera is central to PubCast's production feel. Without a canonical camera contract, every future camera or director feature gets messier.

### C. It degrades honestly
If the bridge is missing or the renderer is absent, the service does not fake full availability.

Instead it reports:
- disconnected if neither path is usable
- degraded if one is partly available
- ready if both basic startup checks pass

That is aligned with the broader PubCast goal of honest behavior over fake-alive behavior.

### D. It gives you a clean API surface to wire next
The service exposes route installers for:
- `GET /api/twin/status`
- `POST /api/twin/scene`
- `POST /api/twin/camera/activate`
- `POST /api/twin/camera/pose`
- `POST /api/twin/command`

That means the control room, studio UI, or any debug panel can start talking to a coherent engine endpoint family.

---

## What this bundle does **not** do yet

This part matters. Do not oversell the bundle.

It does **not** currently prove:
- real frame rendering from the Rust renderer
- a live scene appearing in a real viewport
- actual WebRTC media path success
- actual world navigation integration
- actor/avatar motion integration
- real control-room button wiring in the existing frontend
- end-to-end scene load into a production renderer

It also does **not** replace your full application.

It is a subsystem starter, not a full engine completion.

---

## Why this shape was chosen instead of a larger rewrite

A larger rewrite would be tempting, but it would be the wrong move at this stage.

This shape was chosen because it preserves what matters:
- your existing host app shape can remain intact
- the engine can be mounted incrementally
- camera and scene control can be tested without full renderer completion
- bridge and renderer failures can be isolated instead of taking down everything
- future systems like director logic, room loading, and avatar tracking can plug into a stable contract

In other words:

> the bundle is designed to reduce engine chaos first, then enable deeper capability

That is the right order.

---

## Immediate next steps in the real PubCast repo

These are the practical next moves.

### Step 1 — place the service file in the backend
Copy `pubcast_twin_engine_service.py` into the real backend codebase somewhere appropriate, ideally near your other core service modules.

### Step 2 — mount it from the real `main.py`
Use the pattern from `MAIN_PY_PATCH_EXAMPLE.py`, but adapt it to your real startup flow.

At minimum:
- instantiate or discover the real bridge object
- instantiate or discover the real renderer object if present
- call `await mount_twin_engine(app, bridge=..., renderer=...)`
- install routes with `install_twin_engine_routes(app)`
- ensure shutdown calls `await service.shutdown()`

### Step 3 — bind it to the real bridge contract
Right now the service expects bridge-like objects to support some combination of:
- `connect()` or `start()`
- `send_command(command, payload)`
- `is_connected` or `connected`

If your real bridge has different names, adapt either:
- the bridge object
- or the service's compatibility checks

This is one of the most important real integration points.

### Step 4 — feed in real renderer telemetry
The service already exposes `ingest_telemetry(...)`.

Use that to route real renderer status back into the engine service.
At minimum, feed in whether the renderer is:
- ready
- degraded
- disconnected

Better telemetry later could include:
- fps
- viewport/window alive state
- scene loaded confirmation
- active camera confirmation
- last render timestamp
- last frame hash/id

### Step 5 — wire control-room actions to the `/api/twin/*` routes
Once mounted, start using the routes from a real UI.

First targets should be simple and visible:
- load a known scene
- switch from `main` to `closeup`
- change FOV or position
- confirm `/api/twin/status` reflects the change

Do not jump straight to fancy camera intelligence before this part works.

---

## Recommended build order after integration

This is the most important continuation guidance.

### Phase 1 — host integration proof
Goal:
- service mounted in real `main.py`
- routes available
- bridge attached if available
- status endpoint returns truth from the real app

Definition of done:
- `GET /api/twin/status` responds from the running PubCast host

### Phase 2 — one scene, one camera proof
Goal:
- send one scene load command
- switch to one named camera
- verify the bridge receives the command
- verify status reflects the active scene and camera

Definition of done:
- scene and camera changes are observable in logs or live app state

### Phase 3 — renderer telemetry truth
Goal:
- renderer reports back into `ingest_telemetry(...)`
- status begins reflecting renderer reality instead of just startup assumptions

Definition of done:
- `/api/twin/status` shows live telemetry timestamps and actual renderer state

### Phase 4 — control-room wiring
Goal:
- connect real frontend buttons or controls to these endpoints
- make camera switching visible and testable without console-only work

Definition of done:
- a user can click a UI control and change the active camera

### Phase 5 — cinematic layer
Only after the previous phases are stable.

Then add:
- camera director logic
- shot scoring
- follow/target logic
- emotional or performance camera rules
- smooth transition choreography

Do not move this phase earlier than it belongs.

---

## Technical notes for the next developer or next chat

### Bridge expectations
The current service is bridge-tolerant, but only within a simple contract.
The bridge is expected to expose some or all of:
- `connect()` or `start()`
- `send_command(command, payload)`
- `is_connected` or `connected`
- optional `close()` / `shutdown()` / `aclose()`

### Renderer expectations
The current service checks renderer health through either:
- `health()`
- `get_status()`

and expects a dictionary with at least:
- `ok: true/false`

### Error behavior
The service intentionally does not throw itself into fake-ready states.
Bridge command failures push the service into degraded mode and record `last_error`.

### Default cameras currently seeded
The service currently seeds these cameras if none are registered:
- `main`
- `wide`
- `closeup`
- `overhead`

These are starter defaults only and should later be driven by real scene/camera configuration.

---

## What to be careful about

### 1. Do not mistake route availability for renderer proof
The service can be mounted and fully routable before the renderer truly works.
That is expected.
Do not treat this as full completion.

### 2. Do not duplicate camera state elsewhere
Once this service is mounted, avoid creating a second competing camera state source unless there is a very good reason.
This service should become the canonical camera state holder for the twin-engine path.

### 3. Do not expand architecture before closing the proof loop
It will be tempting to add:
- advanced director logic
- room graph logic
- avatar choreography
- livestream orchestration

Hold that urge until:
- host integration works
- scene command works
- camera switch works
- telemetry works

### 4. Keep the service honest
If something is disconnected, let it say disconnected.
If only some parts work, let it say degraded.
This honesty is part of the architecture goal, not a temporary inconvenience.

---

## Suggested exact next implementation target

If continuing from this bundle, the best immediate target is:

> Mount the service in the real PubCast `main.py`, attach the real bridge, and prove one real scene-load command plus one real camera activation from a reachable `/api/twin/*` endpoint.

That is the highest-value continuation step because it closes the loop between:
- backend host
- engine service
- bridge command path
- visible engine state

After that, telemetry should be made live.
After that, UI wiring.
After that, more cinematic intelligence.

---

## Bottom-line status

This bundle is a **credible engine foundation step**.
It is **not** the completed engine.

It improves the PubCast twin-engine effort by giving it:
- a real mountable service
- a real camera contract
- a real status model
- a real route family
- a testable starting point

That is enough to be worth continuing directly from, and specific enough that the next pass should not lose the thread.
