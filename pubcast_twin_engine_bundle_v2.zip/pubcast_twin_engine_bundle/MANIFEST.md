# PubCast Twin Engine Bundle — Manifest

## File list

1. `pubcast_twin_engine_service.py`
   Main mountable twin-engine service.

2. `MAIN_PY_PATCH_EXAMPLE.py`
   Example FastAPI lifespan mount pattern.

3. `pubcast_twin_engine_demo.py`
   Minimal runnable demo with dummy bridge and renderer.

4. `test_pubcast_twin_engine_service.py`
   Unit tests for startup, activation, and honest disconnected mode.

5. `HANDOFF.md`
   Detailed continuation handoff, intent, limits, and next steps.

6. `MANIFEST.md`
   This file.
